<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>syn/ant</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

    <section class="justify-content-center d-flex mt-5">
        <form>
            <h3 class="mt-5 text-danger fs-1">Add Synonyms/Antonyms Here</h3>

            <div class="mb-3 mt-5">
                <input type="text" class="form-control" id="syn_antWordid" name="syn_antWordid" placeholder="Enter the word Id">
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" name="syn_antWord" id="exampleInputPassword1" placeholder="Enter the word">
            </div>
            <select class="form-select" aria-label="Default select example">
                <option selected>Choose options</option>
                <option value="1">Synonyms</option>
                <option value="2">Antonyms</option>
            </select>
            <div class="mb-3 mt-4">
                <input class="form-control" type="file" id="formFile">
            </div>
            <div>
                <button class="btn btn-danger fs-3">Add</button>
            </div>
        </form>

    </section>


    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>