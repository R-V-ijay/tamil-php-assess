<?php
include("./config/config.php");

if (isset($_POST['logLogin'])) {

    $log_name = $_POST['username'];
    $log_password = $_POST['userpass'];

    $query = "SELECT handler_name,handler_password,handler_email,id,handler_profile from handlers where handler_name='$log_name'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row['handler_password'] == md5($log_password)) {
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['user_name'] = $row['handler_name'];
        $_SESSION['user_email'] = $row['handler_email'];
        $_SESSION['user_profilepic'] = $row['handler_profile'];
        header("location:index.php");
    } else {
        echo "not connect";
    }
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#" style="font-size:40px;font-weight:600">DICTIONARY</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 ms-auto">
                        <li class="nav-item">
                            <a class="btn btn-primary fs-4" href="register.php">Register</a>
                        </li>
                </div>
            </div>
        </nav>
    </section>

    <section class="justify-content-center d-flex mt-5">
        <form method="post">
            <div class="mt-5">
                <h1 class="text-danger">USER LOGIN</h1>
                <div class="mb-3 mt-5">
                    <label for="inputname" class="form-label text-light fs-4">User Name</label>
                    <input type="text" class="form-control w-100" id="inputname" name="username" required>
                </div>
                <div class="mb-3 mt-4">
                    <label for="inputpass" class="form-label text-light fs-4">Password</label>
                    <input type="password" class="form-control w-100" id="inputpass" name="userpass" required>
                </div>
                <div>
                    <button type="submit" class="btn btn-danger fs-4" name="logLogin">Login</button>
                </div>
            </div>
        </form>

    </section>

    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>