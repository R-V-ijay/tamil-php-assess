<?php
session_start();

$conn = mysqli_connect('192.168.7.11:42209', 'tamizharasan_febtrdev_user', 'LrdOCTtbWDsAmA0R', 'tamizharasan_febtrdev_db');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
