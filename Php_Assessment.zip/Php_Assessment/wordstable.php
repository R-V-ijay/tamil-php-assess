<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wordstable</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>
</head>

<body>

    <div>
        <h3>WORDS TABLE</h3>
    </div>
    <div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">IMAGE</th>
                    <th scope="col">WORD</th>
                    <th scope="col">USER</th>
                    <th scope="col">STATUS</th>
                    <th scope="col">ACTION</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td><img src="./assets/img.jfif"></td>
                    <td>Young</td>
                    <td>Thomas shelby</td>
                    <td>1</td>
                    <td>
                        <button class="btn btn-info">Approve</button>
                        <button class="btn btn-warning">Disapprove</button>
                        <button class="btn btn-danger">Delete</button>
                    </td>
                </tr>

            </tbody>
        </table>
    </div>




    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>