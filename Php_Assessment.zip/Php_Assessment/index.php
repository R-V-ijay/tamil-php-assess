<?php

include("./config/config.php");

if (isset($_POST['searchBtn'])) {
    $search_name = $_POST['searchbar'];
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dictionary</title>
    <link rel="stylesheet" href="./assets/CSS/Lib/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
    <script src="./assets/CSS/Lib/bootstrap.bundle.min.js"></script>

<body>
    <section>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="#" id="navb" style="font-size:40px;font-weight:600">DICTIONARY</a>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">


                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 ms-auto">
                        <?php
                        if (isset($_SESSION['user_name'])) {
                        ?>
                            <p class="ms-auto" style="font-size:50px">Welcome <span><?= ($_SESSION['user_name']) ?></span></p>
                            <li class="nav-item ms-3 fs-3">
                                <a class="btn btn-secondary" href="addword.php">+</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-danger ms-3 fs-3" name="logout" href="logout.php">Logout</a>
                            </li>
                        <?php
                        } else {
                        ?>
                            <li class="nav-item">
                                <a class="btn btn-success fs-3" id="loginbtn" href="login.php">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-primary ms-5 fs-3" id="registerbtn" href="register.php">Register</a>

                            </li>
                        <?php
                        }
                        ?>
                </div>
            </div>
        </nav>
    </section>
    <section class="justify-content-center d-flex mt-5">
        <form class="mt-5" method="post">
            <h1 class="text-danger" style="margin-top:200px;margin-left:70px">Search Word Here</h1>
            <div class="mb-3 mt-5">
                <input type="text" class="form-control" style="width:500px;height:70px" name="searchbar" placeholder="Enter word">
            </div>
            <button class="btn btn-primary w-50 fs-5" style="border:none;width:300px;height:50px;font-size:20px" type="submit" name="searchBtn" value="success">Search</button>
        </form>
    </section>



    <script src="./assets/JS/LIb/jquery-3.6.4.min.js"></script>
    <script src="./assets/JS/script.js"></script>
</body>

</html>